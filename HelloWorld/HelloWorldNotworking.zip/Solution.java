public class Solution
{
    public static void main(String args[])
    {
        System.out.printf("HelloWorld!!!!");
    }
}